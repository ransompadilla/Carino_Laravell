<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Educational Background</div>

                <div class="panel-body">
                <pre>
<center>
<img src="me.jpg" width="150" height="150" alt="Ransom"><br>
 <b>RANSOM PADILLA CARINO</b>
 Zone 4 Biasong, Talisay City, Cebu
 09423606851
</center>
<b>Objective:</b>

    To contribute towards the development and growth on the organization. Where I can use my knowledge and skills efficiently.

<b>Personal Information:</b>

    Age     : 22
    Birthdate   : March 6, 1995
    Gender      : Male
    Height      : 173 cm.
    
<b>Skills:</b>

    knowledgeable in Java Script, JAVA, PHP ,ASP, MySQL  and VB.Net programming language.
    Proficient in Microsoft Excel, Power Point, Access.

<b>Educational Background:</b>

    <b>Tertiary:</b>
        Bachelor of Science in Information of Technology
        University of Cebu Main Campus
        Sanciangko st. Cebu City
        3rd year
    <b>Secondary:</b>
        Pooc National Highschool
        Pooc, Talisay City, Cebu
        S.Y: 2007-2012
    <b>Primary:</b>
        Mohon Elementary School
        Mohon, Talisay City, Cebu
        S.Y: 2001-2007

<b>Working Experiece:</b>

    <b>Service Crew</b> (Back-up/Soda)
    September 2015 – Febuary 2016
    Jollibee Food Corporation
    Leon Kilat St. Cebu City

    <b>Sales Clerk</b> (Luggage Department )
    August 2016 – January 2017
    The SM Store Seaside Cebu
    My Shoppinglane Cebu Corp.
    South Road Properties, Cebu
</pre>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>