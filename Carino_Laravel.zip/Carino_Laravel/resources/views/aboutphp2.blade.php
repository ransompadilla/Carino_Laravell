@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">About PHP2</div>

                <div class="panel-body">
                    <b>Topics</b>
                        <ul>
                            <li>Making Template using HTML</li>
                            <li>Introduction of PHP(Refresh from php1)</li>
                            <li>Making Projects using PHP with Database MySql</li>
                            <li>Learning MVC framework</li>
                            <li>Learning Restful API</li>
                            <li>Laravel Framework</li>
                        </ul>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
