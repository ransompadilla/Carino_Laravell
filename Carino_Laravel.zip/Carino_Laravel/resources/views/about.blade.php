@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">About LARAVEL</div>

                <div class="panel-body">
<pre>
    Hi! im Ransom Padilla Carino,  I live in Biasong Talisay City Cebu, im the 3rd baby among the 6 
    siblings. My primary school Mohon Elementary School, Secondary Pooc National Highschool.
         when i was in elementary i always think that i want to become a police man someday, as time 
    passed by when technology speak i found that this is very interesting and it made me change
    my ambition in life thats why i took Bachelor of Science in Information, at first it was so
    hard during examination my answer always depended in my classmate, when i was 2nd year at that
    time i realize this is not good anymore so that i used my time to study and enjoy it.

        and now  the struggle is real DMD. :)
 </pre>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
