@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">My Subjects</div>

                <div class="panel-body">
                    <table class="table table-stripped">
                        <th>SCHED-NO</th><th>COURSE-NO</th><th>TIME</th><th>DAYS</th><th>ROOM</th><th>UNITS</th>
                        <tr>
                            <td>IT-01313</td>
                            <td>DBSYS32(lab)</td>
                            <td>2:30-3:30 PM</td>
                            <td>MWF</td>
                            <td>542</td>
                            <td>0.0</td>
                        </tr>
                        <tr>
                            <td>IT-01313</td>
                            <td>DBSYS32(lec)</td>
                            <td>1:30-2:30 PM</td>
                            <td>TTH</td>
                            <td>530A</td>
                            <td>3.0</td>
                        </tr>
                        <tr>
                            <td>IT-01362</td>
                            <td>AIS32(lab)</td>
                            <td>6:31-8:01 PM</td>
                            <td>TTH</td>
                            <td>542</td>
                            <td>0.0</td>
                        </tr>
                        <tr>
                            <td>IT-01362</td>
                            <td>AIS32(lec)</td>
                            <td>5:31-6:31 PM</td>
                            <td>TTH</td>
                            <td>530A</td>
                            <td>3.0</td>
                        </tr>
                        <tr>
                            <td>IT-01941</td>
                            <td>POLSCI 6</td>
                            <td>4:30-5:30 PM</td>
                            <td>MWF</td>
                            <td>614</td>
                            <td>3.0</td>
                        </tr>
                        <tr>
                            <td>IT-02188</td>
                            <td>ECON 1</td>
                            <td>1:3-2:30 PM</td>
                            <td>MWF</td>
                            <td>615</td>
                            <td>3.0</td>
                        </tr>
                        <tr>
                            <td>IT-02527</td>
                            <td>FREEELNIH</td>
                            <td>1:30-4:30 PM</td>
                            <td>SAT</td>
                            <td>535</td>
                            <td>3.0</td>
                        </tr>
                        <tr>
                            <td>IT-02600</td>
                            <td>ITELECTPHP2(lab)</td>
                            <td>7:31-8:31 PM</td>
                            <td>MWF</td>
                            <td>544</td>
                            <td>0.0</td>
                        </tr><tr>
                            <td>IT-02600</td>
                            <td>ITELECTPHP2(lec)</td>
                            <td>6:31-7:31 PM</td>
                            <td>MWF</td>
                            <td>530A</td>
                            <td>3.0</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>Total Units: </td>
                            <td>18.0</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
